//
//  NavigationViewController.swift
//  ECE564_HOMEWORK
//
//  Created by Nan Ni on 2/10/20.
//  Copyright © 2020 ECE564. All rights reserved.
//

import UIKit

class NavigationViewController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
